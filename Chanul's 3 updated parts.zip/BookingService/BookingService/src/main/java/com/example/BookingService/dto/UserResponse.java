// src/main/java/com/example/bookingservice/dto/UserResponse.java
package com.example.BookingService.dto;

import lombok.Data;

@Data
public class UserResponse {
    private String id;
    private String name;
    private String email;
}