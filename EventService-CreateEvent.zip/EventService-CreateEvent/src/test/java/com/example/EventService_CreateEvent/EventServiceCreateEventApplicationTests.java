package com.example.EventService_CreateEvent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventServiceCreateEventApplicationTests {

	@Test
	void contextLoads() {
	}

}
