package com.example.EventService_CreateEvent.controller;

import com.example.EventService_CreateEvent.entity.Event;
import com.example.EventService_CreateEvent.exception.EventCreateException;
import com.example.EventService_CreateEvent.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/events")
public class EventController {
    @Autowired
    private EventService eventService;

    @PostMapping
    public ResponseEntity<?> createEvent(@RequestBody Event event) {
        try {
            Event savedEvent = eventService.createEvent(event);
            return ResponseEntity.ok(savedEvent);
        } catch (EventCreateException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}