package com.example.UserService.controller;

import com.example.UserService.entity.User;
import com.example.UserService.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Endpoint to get all users
    @GetMapping
    public ResponseEntity<List<User>> getUsers() {
        List<User> users = userService.getAllUsers();  // Fetch all users from the service
        return ResponseEntity.ok(users);
    }

    // Endpoint to get a user by their ID
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);  // Fetch the user by ID
        return user.map(ResponseEntity::ok)   // If user is present, return 200 OK
                .orElseGet(() -> ResponseEntity.notFound().build());  // If not found, return 404 Not Found
    }
}
