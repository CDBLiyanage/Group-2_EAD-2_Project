// src/main/java/com/example/bookingservice/config/EventServiceClient.java
package com.example.BookingService.config;

import com.example.BookingService.dto.EventDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(name = "event-service", url = "http://localhost:8081")
public interface EventServiceClient {
    @GetMapping("/events/{eventId}")
    EventDTO getEvent(@PathVariable("eventId") String eventId);

    @PutMapping("/events/{eventId}/reserve")
    void reserveSeat(@PathVariable("eventId") String eventId);
}