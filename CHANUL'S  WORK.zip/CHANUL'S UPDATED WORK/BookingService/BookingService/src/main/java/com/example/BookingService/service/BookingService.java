package com.example.BookingService.service;

import com.example.BookingService.dto.BookingRequest;
import com.example.BookingService.entity.Booking;
import com.example.BookingService.repository.BookingRepository;
import com.example.BookingService.service.EventServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookingService {
    private final BookingRepository bookingRepository;
    private final EventServiceClient eventServiceClient;

    @Transactional
    public Booking createBooking(BookingRequest request) {
        // 1. Reserve a seat in Event Service
        eventServiceClient.reserveSeat(request.getEventId());

        // 2. Create booking
        Booking booking = new Booking();
        booking.setUserId(request.getUserId());
        booking.setEventId(request.getEventId());

        return bookingRepository.save(booking);
    }
}