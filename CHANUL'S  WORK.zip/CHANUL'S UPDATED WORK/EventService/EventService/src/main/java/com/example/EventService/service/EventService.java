package com.example.EventService.service;

import com.example.EventService.entity.Event;
import com.example.EventService.repository.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventService {
    private final EventRepository eventRepository;

    public List<Event> getAllUpcomingEvents() {
        return eventRepository.findByDateAfter(LocalDateTime.now());
    }

    @Transactional
    public void reserveSeat(Long eventId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Event not found with ID: " + eventId));

        if (event.getAvailableSeats() <= 0) {
            throw new RuntimeException("No seats available for event: " + eventId);
        }

        event.setAvailableSeats(event.getAvailableSeats() - 1);
        eventRepository.save(event);
    }
}