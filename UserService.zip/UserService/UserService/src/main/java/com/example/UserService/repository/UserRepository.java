package com.example.UserService.repository;

public interface UserRepository {
}
