package com.example.EventService_CreateEvent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventServiceCreateEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventServiceCreateEventApplication.class, args);
	}

}
