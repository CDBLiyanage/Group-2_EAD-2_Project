package com.example.EventService_CreateEvent.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Title is required")
    private String title;

    @NotBlank(message = "Description is required")
    private String description;

    @NotNull(message = "Date is required")
    private LocalDateTime date;

    @NotNull(message = "Location is required")
    private Long location;

    @NotNull(message = "Organizer ID is required")
    private Long organizerId; // Reference to UserService (no foreign key)

    @NotNull(message = "Total seats is required")
    private Long totalSeats;

    @NotNull(message = "Available seats is required")
    private Long availableSeats;
}