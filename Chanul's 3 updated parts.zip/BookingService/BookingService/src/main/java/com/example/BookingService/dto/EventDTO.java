// src/main/java/com/example/bookingservice/dto/EventDTO.java
package com.example.BookingService.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class EventDTO {
    private String id;
    private String title;
    private String description;
    private LocalDateTime date;
    private String location;
    private String organizerId;
    private int totalSeats;
    private int availableSeats;
}