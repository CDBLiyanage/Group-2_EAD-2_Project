package com.example.BookingService.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings")
@Data
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private String userId; // From User Service (no foreign key)

    @Column(name = "event_id")
    private String eventId; // From Event Service (no foreign key)

    @Column(name = "booking_date")
    private LocalDateTime bookingDate;
}