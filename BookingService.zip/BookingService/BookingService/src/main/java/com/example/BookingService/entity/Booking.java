package com.example.BookingService.entity;

public class Booking {
}
