package com.example.BookingService_EventAttendees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingServiceEventAttendeesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingServiceEventAttendeesApplication.class, args);
	}

}
