package com.example.BookingService.service;

import com.example.BookingService.entity.Booking;
import com.example.BookingService.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    // Method to cancel a booking
    public ResponseEntity<String> cancelBooking(Long id) {
        Booking booking = bookingRepository.findById(id).orElse(null);
        if (booking != null) {
            bookingRepository.delete(booking);
            return ResponseEntity.ok("Booking canceled successfully.");
        }
        return ResponseEntity.notFound().build(); // Return 404 if booking is not found
    }
}
