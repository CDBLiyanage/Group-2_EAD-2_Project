package com.example.EventService.entity;

public class Event {
}
