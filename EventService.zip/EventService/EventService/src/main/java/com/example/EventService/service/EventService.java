package com.example.EventService.service;

public class EventService {
}
