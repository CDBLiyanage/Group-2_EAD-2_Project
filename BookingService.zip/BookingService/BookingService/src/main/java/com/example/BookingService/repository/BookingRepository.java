package com.example.BookingService.repository;

public interface BookingRepository {
}
