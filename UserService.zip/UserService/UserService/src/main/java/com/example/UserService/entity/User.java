package com.example.UserService.entity;

public class User {
}
