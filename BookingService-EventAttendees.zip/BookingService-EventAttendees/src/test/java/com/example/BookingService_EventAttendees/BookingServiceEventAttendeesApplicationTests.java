package com.example.BookingService_EventAttendees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingServiceEventAttendeesApplicationTests {

	@Test
	void contextLoads() {
	}

}
