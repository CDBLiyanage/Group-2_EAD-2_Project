package com.example.UserService.controller;

public class UserController {
}
