package com.example.EventService.controller;

public class EventController {
}
