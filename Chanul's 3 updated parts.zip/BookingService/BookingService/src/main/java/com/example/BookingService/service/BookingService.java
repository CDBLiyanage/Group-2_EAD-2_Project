package com.example.BookingService.service;

import com.example.BookingService.config.EventServiceClient;
import com.example.BookingService.config.UserServiceClient;
import com.example.BookingService.entity.Booking;
import com.example.BookingService.dto.EventDTO;
import com.example.BookingService.dto.UserDTO;
import com.example.BookingService.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class BookingService {
    private final BookingRepository bookingRepository;
    private final UserServiceClient userServiceClient;
    private final EventServiceClient eventServiceClient;

    public Booking createBooking(String userId, String eventId) {
        // 1. Validate user exists (using DTO)
        UserDTO user = userServiceClient.getUser(userId);
        if (user == null) throw new RuntimeException("User not found");

        // 2. Validate event exists and has seats (using DTO)
        EventDTO event = eventServiceClient.getEvent(eventId);
        if (event == null || event.getAvailableSeats() <= 0) {
            throw new RuntimeException("Event not available");
        }

        // 3. Reserve a seat
        eventServiceClient.reserveSeat(eventId);

        // 4. Create booking
        Booking booking = new Booking();
        booking.setUserId(userId);
        booking.setEventId(eventId);
        booking.setBookingDate(LocalDateTime.now());
        return bookingRepository.save(booking);
    }
}