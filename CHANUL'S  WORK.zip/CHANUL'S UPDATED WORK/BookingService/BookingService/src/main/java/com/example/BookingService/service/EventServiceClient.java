package com.example.BookingService.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "event-service", url = "http://localhost:8081")
public interface EventServiceClient {
    @PutMapping("/events/{eventId}/reserve")
    void reserveSeat(@PathVariable Long eventId); // Use Long instead of String
}