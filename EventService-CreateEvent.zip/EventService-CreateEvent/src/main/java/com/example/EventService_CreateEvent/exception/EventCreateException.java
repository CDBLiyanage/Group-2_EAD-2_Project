package com.example.EventService_CreateEvent.exception;

public class EventCreateException extends RuntimeException {
    public EventCreateException(String message) {
        super(message);
    }
}