package com.example.BookingService_EventAttendees.controller;
import java.util.List;


import com.example.BookingService_EventAttendees.entity.Booking;
import com.example.BookingService_EventAttendees.exception.BookingNotFoundException;
import com.example.BookingService_EventAttendees.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @GetMapping("/event/{eventId}")
    public ResponseEntity<?> getAttendees(@PathVariable Long eventId) {
        try {
            List<Booking> bookings = bookingService.getAttendeesByEventId(eventId);
            return ResponseEntity.ok(bookings);
        } catch (BookingNotFoundException ex) {
            return ResponseEntity.status(404).body(ex.getMessage());
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}