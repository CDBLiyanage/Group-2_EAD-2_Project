package com.example.EventService_CreateEvent.controller;

import com.example.EventService_CreateEvent.entity.Event;
import com.example.EventService_CreateEvent.exception.EventCreateException;
import com.example.EventService_CreateEvent.repository.EventRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/events")
public class EventController {
    @Autowired
    private EventRepository eventRepository;

    @PostMapping
    public ResponseEntity<?> createEvent(@Valid @RequestBody Event event) {
        try {
            // Validate available seats
            if (event.getAvailableSeats() > event.getTotalSeats()) {
                throw new EventCreateException("Available seats cannot exceed total seats");
            }

            // Save the event to the database
            Event savedEvent = eventRepository.save(event);
            return ResponseEntity.ok(savedEvent);
        } catch (DataAccessException ex) {
            // Handle database errors
            throw new EventCreateException("Failed to create event due to a database error");
        } catch (EventCreateException ex) {
            // Handle custom business logic errors
            throw ex;
        } catch (Exception ex) {
            // Handle any other unexpected errors
            throw new EventCreateException("An unexpected error occurred while creating the event");
        }
    }
}