package com.example.BookingService.dto;

import lombok.Data;

@Data
public class BookingRequest {
    private Long userId;
    private Long eventId;
}