package com.example.BookingService.controller;

public class BookingController {
}
