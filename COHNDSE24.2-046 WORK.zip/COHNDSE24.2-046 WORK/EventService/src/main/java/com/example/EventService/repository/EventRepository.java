package com.example.EventService.repository;

import com.example.EventService.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
    // Custom query to find upcoming events
    List<Event> findByDateAfter(LocalDateTime currentDate);
}