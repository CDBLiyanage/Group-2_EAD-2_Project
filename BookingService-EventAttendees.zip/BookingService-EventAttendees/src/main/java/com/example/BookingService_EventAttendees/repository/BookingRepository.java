package com.example.BookingService_EventAttendees.repository;

import com.example.BookingService_EventAttendees.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByEventId(Long eventId);
}
