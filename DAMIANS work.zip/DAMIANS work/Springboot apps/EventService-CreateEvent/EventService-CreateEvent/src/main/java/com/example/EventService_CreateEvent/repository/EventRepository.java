package com.example.EventService_CreateEvent.repository;

import com.example.EventService_CreateEvent.entity.Event; // Correct import
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<Event, Long> {}