package com.example.EventService.repository;

public interface EventRepository {
}
