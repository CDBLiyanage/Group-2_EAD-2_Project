package com.example.EventService.controller;

import com.example.EventService.entity.Event;
import com.example.EventService.service.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
@RequiredArgsConstructor
public class EventController {
    private final EventService eventService;

    @GetMapping
    public List<Event> getAllUpcomingEvents() {
        return eventService.getAllUpcomingEvents();
    }

    // New PUT endpoint for seat reservation
    @PutMapping("/{eventId}/reserve")
    public void reserveSeat(@PathVariable Long eventId) {
        eventService.reserveSeat(eventId);
    }
}