package com.example.UserService.service;

public class UserService {
}
