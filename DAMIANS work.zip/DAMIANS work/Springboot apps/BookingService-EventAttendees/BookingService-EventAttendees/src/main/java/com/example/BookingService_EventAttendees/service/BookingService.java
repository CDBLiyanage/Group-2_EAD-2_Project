package com.example.BookingService_EventAttendees.service;


import com.example.BookingService_EventAttendees.entity.Booking;
import com.example.BookingService_EventAttendees.exception.BookingNotFoundException;
import com.example.BookingService_EventAttendees.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public List<Booking> getAttendeesByEventId(Long eventId) {
        // Validate eventId
        if (eventId == null || eventId <= 0) {
            throw new IllegalArgumentException("Invalid event ID");
        }

        // Fetch bookings by eventId
        List<Booking> bookings = bookingRepository.findByEventId(eventId);

        // Handle case where no bookings are found
        if (bookings.isEmpty()) {
            throw new BookingNotFoundException("No bookings found for event ID: " + eventId);
        }

        return bookings;
    }
}