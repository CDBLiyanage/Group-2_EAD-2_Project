package com.example.BookingService.service;

public class BookingService {
}
