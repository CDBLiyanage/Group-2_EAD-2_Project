package com.example.BookingService_EventAttendees.controller;


import com.example.BookingService_EventAttendees.entity.Booking;
import com.example.BookingService_EventAttendees.exception.BookingNotFoundException;
import com.example.BookingService_EventAttendees.exception.GlobalExceptionHandler;
import com.example.BookingService_EventAttendees.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
    @Autowired
    private BookingRepository bookingRepository;

    @GetMapping("/event/{eventId}")
    public ResponseEntity<?> getAttendees(@PathVariable Long eventId) {
        try {
            // Validate eventId
            if (eventId == null || eventId <= 0) {
                throw new IllegalArgumentException("Invalid event ID");
            }

            // Fetch bookings by eventId
            List<Booking> bookings = bookingRepository.findByEventId(eventId);

            // Handle case where no bookings are found
            if (bookings.isEmpty()) {
                throw new BookingNotFoundException("No bookings found for event ID: " + eventId);
            }

            return ResponseEntity.ok(bookings);
        } catch (IllegalArgumentException ex) {
            // Handle invalid eventId
            throw ex;
        } catch (BookingNotFoundException ex) {
            // Handle no bookings found
            throw ex;
        } catch (Exception ex) {
            // Handle any other unexpected errors
            throw new RuntimeException("An unexpected error occurred while fetching bookings");
        }
    }
}