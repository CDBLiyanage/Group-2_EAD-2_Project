package com.example.EventService_CreateEvent.service;

import com.example.EventService_CreateEvent.entity.Event;
import com.example.EventService_CreateEvent.exception.EventCreateException;
import com.example.EventService_CreateEvent.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event createEvent(Event event) {
        // Validate available seats
        if (event.getAvailableSeats() > event.getTotalSeats()) {
            throw new EventCreateException("Available seats cannot exceed total seats");
        }

        // Save the event to the database
        try {
            return eventRepository.save(event);
        } catch (Exception ex) {
            throw new EventCreateException("Failed to create event due to a database error");
        }
    }
}