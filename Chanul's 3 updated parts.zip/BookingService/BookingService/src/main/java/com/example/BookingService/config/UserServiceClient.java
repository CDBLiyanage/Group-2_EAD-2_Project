// src/main/java/com/example/BookingService/config/UserServiceClient.java
package com.example.BookingService.config;

import com.example.BookingService.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "http://localhost:8080/rest-app")
public interface UserServiceClient {
    @GetMapping("/users/{userId}")
    UserDTO getUser(@PathVariable("userId") String userId); // Fix: Use @PathVariable
}